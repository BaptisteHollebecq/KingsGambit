using UnityEditor;
using UnityEngine;
using UnityEngine.Internal;
using System;

namespace AmplifyShaderEditor
{
	public class UndoUtils
	{
		
	}
}
